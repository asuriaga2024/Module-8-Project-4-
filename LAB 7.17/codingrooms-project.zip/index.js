function sortEvens(numArray) {
    // TODO: Write your solution here
   let evenArray = numArray.filter(num => num % 2 === 0);
   evenArray.sort((a,b) => a - b);
   return evenArray;
}

console.log("Testing sortEvens()...");
let nums = [4, 2, 9, 1, 8];
let evenNums = sortEvens(nums);
console.log(evenNums);


// Do NOT remove the following line:
export default sortEvens;